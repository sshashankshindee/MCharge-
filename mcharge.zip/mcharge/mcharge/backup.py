import time
import serial
import keyboard
import serial.tools.list_ports

# Function to list available COM ports
def list_com_ports():
    ports = serial.tools.list_ports.comports()
    available_ports = [port.device for port in ports]
    print("Available COM ports: ", available_ports)
    return available_ports

# Check and select the correct COM port
available_ports = list_com_ports()

# If no COM ports found, exit the program
if not available_ports:
    print("No available COM ports found. Exiting...")
    exit()

# Set the COM port statically to COM5
com_port = "COM5"

# Configure serial port
try:
    ser = serial.Serial(port=com_port, baudrate=9600, bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)
    print(f"Successfully connected to {com_port}")
except serial.SerialException as e:
    print(f"Could not open port {com_port}: {e}")
    exit()

# Function to construct and send the message
def send_command(device_id, led_color, lock_status):
    message = f"${device_id:02}{led_color:02}{lock_status:02}"
    ser.write(message.encode('Ascii'))
    print(f"Sent command: {message} to device {device_id:02} (LED {'blue' if led_color == 1 else 'green'}, Lock {'open' if lock_status == 1 else 'closed'})")

# Start sending and receiving data
def run_charging_station():
    print("New session started. Token assigned: 00001")
    print("Press '1' to '5' to select the device (compartment),")
    print("Press 'b' for blue LED, 'g' for green LED,")
    print("Press 'o' to open the lock, 'c' to close the lock.")

    selected_device = None
    led_color = None
    lock_status = None

    try:
        while True:
            # Select the device ID (compartment number)
            for device_id in range(1, 6):
                if keyboard.is_pressed(str(device_id)):
                    selected_device = device_id
                    print(f"Device {selected_device} selected.")
                    time.sleep(0.2)  # Debounce to avoid multiple keypresses

            # Set LED color
            if keyboard.is_pressed('b'):
                led_color = 1  # Blue LED
                print("Blue LED selected.")
                time.sleep(0.2)
            elif keyboard.is_pressed('g'):
                led_color = 2  # Green LED
                print("Green LED selected.")
                time.sleep(0.2)

            # Set lock status
            if keyboard.is_pressed('o'):
                lock_status = 1  # Open lock
                print("Lock open selected.")
                time.sleep(0.2)
            elif keyboard.is_pressed('c'):
                lock_status = 0  # Close lock
                print("Lock closed selected.")
                time.sleep(0.2)

            # Send command when all values are selected
            if selected_device and led_color is not None and lock_status is not None:
                send_command(selected_device, led_color, lock_status)

                # Reset values after sending the command
                selected_device = None
                led_color = None
                lock_status = None

            # Check if 'q' is pressed to quit the application
            if keyboard.is_pressed('q'):
                print("User pressed 'q'. Exiting...")
                break
    except KeyboardInterrupt:
        print("User interrupted the program.")
    finally:
        # Close the serial port when done
        ser.close()
        print("Serial port closed.")

# Run the mobile charging station simulation
run_charging_station()
