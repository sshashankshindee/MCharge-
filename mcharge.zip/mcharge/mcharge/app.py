import time
import serial
import serial.tools.list_ports
import json
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Global variable for the serial connection
ser = None
PIN_STORAGE_FILE = 'pins.json'  # File to store the PINs

def setup_serial_connection():
    global ser
    ports = list(serial.tools.list_ports.comports())
    
    if not ports:
        print("No COM ports found!")
        return
    
    for port in ports:
        try:
            print(f"Trying to connect to {port.device}...")
            ser = serial.Serial(port=port.device, baudrate=9600, bytesize=8, timeout=2, stopbits=serial.STOPBITS_ONE)
            if ser.is_open:
                print(f"Successfully connected to {port.device}")
                break
        except serial.SerialException as e:
            print(f"Failed to connect to {port.device}: {e}")

    if ser is None or not ser.is_open:
        print("Could not establish a connection to any available COM port.")

# Function to read the PIN storage file
def load_pin_data():
    try:
        with open(PIN_STORAGE_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

# Function to write PIN data to file
def save_pin_data(pin_data):
    with open(PIN_STORAGE_FILE, 'w') as f:
        json.dump(pin_data, f)

# Function to store a PIN for a compartment
def set_compartment_pin(compartment_id, pin):
    pin_data = load_pin_data()
    pin_data[compartment_id] = pin
    save_pin_data(pin_data)

# Function to retrieve and validate a PIN for a compartment
def get_compartment_pin(compartment_id):
    pin_data = load_pin_data()
    return pin_data.get(compartment_id)

# Function to reset (delete) the PIN after retrieval
def reset_compartment_pin(compartment_id):
    pin_data = load_pin_data()
    if compartment_id in pin_data:
        del pin_data[compartment_id]
        save_pin_data(pin_data)

# Function to construct and send the message
@app.route('/send_command', methods=['POST'])
def send_command_route():
    data = request.json
    message = data.get('message')

    print(f"Received message to send to serial device: {message}")

    if message and message.startswith('$'):
        try:
            # Send the command to the serial device
            ser.write(message.encode('Ascii'))
            print(f"Sent command: {message}")

            # Immediately send a success response
            success_response = jsonify(message="Command sent successfully.")
            # Check for a response from the device asynchronously
            response = read_response()
            
            if response:
                print(f"Response from device: {response}")
            else:
                print("No response received from the device.")
            
            return success_response
        except Exception as e:
            print(f"Error sending command: {e}")
            return jsonify(message="Failed to send command."), 500

    return jsonify(message="Invalid command format!"), 400

def send_command(device_id, led_color, lock_status):
    if ser is not None:
        lock_status_value = '01' if lock_status == 1 else '02'  # 01 for unlock, 02 for lock
        message = f"${device_id:02}{led_color:02}{lock_status_value}"
        ser.write(message.encode('Ascii'))
        print(f"Sent command: {message} to device {device_id:02}")

        # Wait for a response from the device
        response = read_response()
        if response:
            print(f"Response from device: {response}")
        else:
            print("No response received or timed out.")

def read_response():
    try:
        # Adding a short delay before attempting to read
        time.sleep(0.5)  # Adjust this value as needed (e.g., 1 second)
        
        # Increase the timeout to wait for a potential response
        ser.timeout = 5
        response = ser.readline()
        
        if response:
            decoded_response = response.decode('ISO-8859-1').strip()
            print(f"Decoded response: {decoded_response}")
            return decoded_response
        else:
            print(f"No text response; raw bytes: {response.hex()}")
            return None
    except Exception as e:
        print(f"Error reading response: {e}")
        return None



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/set_pin', methods=['POST'])
def set_pin():
    data = request.json
    compartment_id = data.get('compartment_id')
    pin = data.get('pin')

    if compartment_id and pin:
        set_compartment_pin(compartment_id, pin)
        return jsonify(message="PIN set successfully!")
    return jsonify(message="Invalid parameters!"), 400

@app.route('/retrieve_pin', methods=['POST'])
def retrieve_pin():
    data = request.json
    compartment_id = data.get('compartment_id')
    pin = data.get('pin')

    stored_pin = get_compartment_pin(compartment_id)
    if stored_pin is None:
        return jsonify(message="No PIN set for this compartment!"), 400

    if stored_pin == pin:
        # Open the compartment and reset the PIN
        send_command(compartment_id, 1, 1)  # Open compartment with blue LED
        reset_compartment_pin(compartment_id)
        return jsonify(message="Compartment opened! PIN reset.")
    else:
        return jsonify(message="Invalid PIN!"), 400

if __name__ == '__main__':
    setup_serial_connection()
    app.run(debug=True, use_reloader=False)
