document.getElementById('startBtn').style.display = 'block';

document.getElementById('startBtn').addEventListener('click', function() {
    document.getElementById('startBtn').style.display = 'none';
    document.getElementById('deviceSelection').style.display = 'flex';
});

let selectedDevice = null;

document.querySelectorAll('.deviceBox').forEach(box => {
    box.addEventListener('click', function() {
        document.querySelectorAll('.deviceBox').forEach(b => b.classList.remove('selected'));
        box.classList.add('selected');
        selectedDevice = box.getAttribute('data-device-id');
        console.log('Device selected: ' + selectedDevice);
        document.getElementById('openLockBtn').style.display = 'block';
    });
});

document.getElementById('openLockBtn').addEventListener('click', function() {
    if (selectedDevice) {
        fetch('/send_command', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                device_id: selectedDevice,
                led_color: 1,  // Blue LED
                lock_status: 1  // Open lock
            })
        })
        .then(response => response.json())
        .then(data => console.log(data));

        document.getElementById('pinForm').style.display = 'block';
    }
});

document.getElementById('submitPinBtn').addEventListener('click', function() {
    const pin = document.getElementById('pin').value;
    const confirmPin = document.getElementById('confirmPin').value;

    if (pin === confirmPin && pin.length === 4) {
        console.log('PIN set successfully:', pin);
        alert('PIN set successfully!');
    } else {
        alert('PINs do not match or are not 4 digits!');
    }
});
