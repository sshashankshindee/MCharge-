import re
import smtplib
import dns.resolver
from email_validator import validate_email, EmailNotValidError

def is_valid_syntax(email):
    try:
        validate_email(email)
        return True
    except EmailNotValidError:
        return False

def has_mx_record(domain):
    try:
        records = dns.resolver.resolve(domain, 'MX')
        return bool(records)
    except Exception:
        return False

def smtp_check(email):
    domain = email.split('@')[1]
    try:
        with smtplib.SMTP() as server:
            server.connect(f'mx.{domain}')
            server.helo()
            return True
    except Exception:
        return False

def verify_email(email):
    if not is_valid_syntax(email):
        return {"status": "invalid", "reason": "Invalid syntax"}

    domain = email.split('@')[1]
    if not has_mx_record(domain):
        return {"status": "invalid", "reason": "No MX record"}

    if smtp_check(email):
        return {"status": "valid"}
    else:
        return {"status": "invalid", "reason": "SMTP check failed"}
